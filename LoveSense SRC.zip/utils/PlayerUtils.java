package net.ccbluex.liquidbounce.utils;

import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

public final class PlayerUtils {
    public static final Minecraft mc = Minecraft.getMinecraft();
    private static int damage;


    public static float getDirection() {
        Minecraft.getMinecraft();
        float yaw = mc.thePlayer.rotationYaw;
        Minecraft.getMinecraft();
        if (mc.thePlayer.moveForward < 0.0f) {
            yaw += 180.0f;
        }
        float forward = 1.0f;
        Minecraft.getMinecraft();
        if (mc.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else {
            Minecraft.getMinecraft();
            if (mc.thePlayer.moveForward > 0.0f) {
                forward = 0.5f;
            }
        }
        Minecraft.getMinecraft();
        if (mc.thePlayer.moveStrafing > 0.0f) {
            yaw -= 90.0f * forward;
        }
        Minecraft.getMinecraft();
        if (mc.thePlayer.moveStrafing < 0.0f) {
            yaw += 90.0f * forward;
        }
        return yaw *= 0.017453292f;
    }
    public static boolean isHoldingSword() {
        return mc.thePlayer.getCurrentEquippedItem() != null && mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemSword;
    }
    public static float angleDifference(float a, float b){
        return ((((a - b) % 360) + 540f) % 360) - 180f;
    }
    public static boolean isOnSameTeam(EntityPlayer entity) {
        if (entity.getTeam() != null && mc.thePlayer.getTeam() != null) {
            char c2;
            char c1 = entity.getDisplayName().getFormattedText().charAt(1);
            return c1 == (c2 = mc.thePlayer.getDisplayName().getFormattedText().charAt(1));
        }
        return false;
    }

    public static boolean isInLiquid() {
        boolean inLiquid = false;
        AxisAlignedBB playerBB = mc.thePlayer.getEntityBoundingBox();
        int y = (int)playerBB.minY;
        for (int x = MathHelper.floor_double(playerBB.minX); x < MathHelper.floor_double(playerBB.maxX) + 1; ++x) {
            for (int z = MathHelper.floor_double(playerBB.minZ); z < MathHelper.floor_double(playerBB.maxZ) + 1; ++z) {
                Block block = mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block == null || block instanceof BlockAir) continue;
                if (!(block instanceof BlockLiquid)) {
                    return false;
                }
                inLiquid = true;
            }
        }
        return inLiquid;
    }

    public static boolean isOnLiquid() {
        boolean onLiquid = false;
        AxisAlignedBB playerBB = mc.thePlayer.getEntityBoundingBox();
        WorldClient world = mc.theWorld;
        int y = (int)playerBB.offset((double)0.0, (double)-0.01, (double)0.0).minY;
        for (int x = MathHelper.floor_double(playerBB.minX); x < MathHelper.floor_double(playerBB.maxX) + 1; ++x) {
            for (int z = MathHelper.floor_double(playerBB.minZ); z < MathHelper.floor_double(playerBB.maxZ) + 1; ++z) {
                Block block = world.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block == null || block instanceof BlockAir) continue;
                if (!(block instanceof BlockLiquid)) {
                    return false;
                }
                onLiquid = true;
            }
        }
        return onLiquid;
    }

    public static boolean isOnHypixel() {
        return !mc.isSingleplayer() && mc.getCurrentServerData().serverIP.contains("hypixel");
    }

    public static void damageuhc() {
        if (PlayerUtils.mc.thePlayer.onGround) {
            double offset = 0.0601f;
            NetHandlerPlayClient netHandler = mc.getNetHandler();
            EntityPlayerSP player = PlayerUtils.mc.thePlayer;
            double x2 = player.posX;
            double y2 = player.posY;
            double z2 = player.posZ;
            int i2 = 0;
            while ((double)i2 < ((double)PlayerUtils.getMaxFallDist() + 1.0) / 0.05510000046342611 + 1.0) {
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x2, y2 + (double)0.0601f, z2, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x2, y2 + (double)5.0E-4f, z2, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x2, y2 + (double)0.005f + 6.01000003516674E-8, z2, false));
                ++i2;
            }
            netHandler.addToSendQueue(new C03PacketPlayer(true));
        }
    }

    public static void newdamage() {
        if (PlayerUtils.mc.thePlayer.onGround) {
            if (damage < 1)
                damage = 1;
            if (damage > MathHelper.floor_double(mc.thePlayer.getMaxHealth()))
                damage = MathHelper.floor_double(mc.thePlayer.getMaxHealth());

            for (int i = 0; i < 10; i++)
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, true));

            double fallDistance = 3.0125;
            while (fallDistance > 0) {
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0624986421, mc.thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0625, mc.thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0624986421, mc.thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0000006324, mc.thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.00000012437, mc.thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0000005685, mc.thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0000002154, mc.thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0000001351, mc.thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.0000004563, mc.thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.000000312, mc.thePlayer.posZ, false));

                fallDistance -= 0.0624986421;
            }
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, true));


        }
    }

    public static void damage() {
        if (PlayerUtils.mc.thePlayer.onGround) {
            double offset = 0.0601f;
            NetHandlerPlayClient netHandler = mc.getNetHandler();
            EntityPlayerSP player = PlayerUtils.mc.thePlayer;
            double x2 = player.posX;
            double y2 = player.posY;
            double z2 = player.posZ;
            int i2 = 0;
            double i = 0;
            double x = player.posX;
            double y = player.posY;
            double z = player.posZ;


            while (i < PlayerUtils.getMaxFallDist() / 0.05510000046342611 + 1.0) {
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.060100000351667404, z, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 5.000000237487257E-4, z, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.004999999888241291 + 6.01000003516674E-8, z, false));
                ++i;
            }
            netHandler.addToSendQueue(new C03PacketPlayer(true));

        }
    }

    public static void damage2() {
        if (PlayerUtils.mc.thePlayer.onGround) {
            double offset = 0.0601f;
            NetHandlerPlayClient netHandler = mc.getNetHandler();
            EntityPlayerSP player = PlayerUtils.mc.thePlayer;
            double x2 = player.posX;
            double y2 = player.posY;
            double z2 = player.posZ;
            int i2 = 0;
            double i = 0;
            double x = player.posX;
            double y = player.posY;
            double z = player.posZ;
            while (i < PlayerUtils.getMaxFallDist() / 0.05510000046342611 + 1.0) {
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.060100000351667404, z, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 5.000000237487257E-4, z, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.004999999888241291 + 6.01000003516674E-8, z, false));
                ++i;
            }
            netHandler.addToSendQueue(new C03PacketPlayer(true));
        }
    }


    public static float getMaxFallDist() {
        PotionEffect potioneffect = mc.thePlayer.getActivePotionEffect(Potion.jump);
        int f2 = potioneffect != null ? potioneffect.getAmplifier() + 1 : 0;
        return PlayerUtils.mc.thePlayer.getMaxFallHeight() + f2;
        //  int f = potioneffect != null ? potioneffect.getAmplifier() + 1 : 0;
        //return mc.thePlayer.getMaxFallHeight() + f;
    }

    public static boolean isBlockUnder() {
        EntityPlayerSP player = PlayerUtils.mc.thePlayer;
        WorldClient world = PlayerUtils.mc.theWorld;
        AxisAlignedBB pBb = player.getEntityBoundingBox();
        double height = player.posY + (double)player.getEyeHeight();
        int offset = 0;
        while ((double)offset < height) {
            if (!world.getCollidingBoundingBoxes(player, pBb.offset(0.0, -offset, 0.0)).isEmpty()) {
                return true;
            }
            offset += 2;
        }
        return false;
    }

    public static boolean isInsideBlock() {
        EntityPlayerSP player = PlayerUtils.mc.thePlayer;
        WorldClient world = PlayerUtils.mc.theWorld;
        AxisAlignedBB bb = player.getEntityBoundingBox();
        for (int x = MathHelper.floor_double(bb.minX); x < MathHelper.floor_double(bb.maxX) + 1; ++x) {
            for (int y = MathHelper.floor_double(bb.minY); y < MathHelper.floor_double(bb.maxY) + 1; ++y) {
                for (int z = MathHelper.floor_double(bb.minZ); z < MathHelper.floor_double(bb.maxZ) + 1; ++z) {
                    AxisAlignedBB boundingBox;
                    Block block = world.getBlockState(new BlockPos(x, y, z)).getBlock();
                    if (block == null || block instanceof BlockAir || (boundingBox = block.getCollisionBoundingBox(world, new BlockPos(x, y, z), world.getBlockState(new BlockPos(x, y, z)))) == null || !player.getEntityBoundingBox().intersectsWith(boundingBox)) continue;
                    return true;
                }
            }
        }
        return false;
    }
}

