/*
 * Decompiled with CFR 0_132.
 */
package net.ccbluex.liquidbounce.utils;


import net.minecraft.potion.Potion;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MathUtil {
    public static double round(double num, double increment) {
        if (increment < 0.0) {
            throw new IllegalArgumentException();
        }
        BigDecimal bd = new BigDecimal(num);
        bd = bd.setScale((int)increment, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    public static double randomNumber(double max, double min) {
        double t = min;
        if (max < min) {
            min = max;
            max = t;
        }
        return Math.random() * (max - min) + min;
    }

}

