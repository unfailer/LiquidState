package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.util.ResourceLocation;

@ModuleInfo(name = "Capes", description = "Capes", category = ModuleCategory.RENDER)
public class Capes extends Module {
    public static ListValue modeValue = new ListValue("Mode", new String[]{"LiquidBounce", "ETB" ,"Funny", "Envy" ,"Sunny" ,"Hypixel"}, "Sunny");

}