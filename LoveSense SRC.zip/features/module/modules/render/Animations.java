package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.ListValue;


@ModuleInfo(name = "Animations", description = "Animation for blocking.", category = ModuleCategory.RENDER)
public class Animations extends Module {
    public static final ListValue getModeValue = new ListValue("Mode", new String[] {"Sigma","Remix","Exhibition","Swank","Slide","Jello","Rotato","Push","Vanilla","ETB"}, "Exhibition");
    public static FloatValue itemPosX = new FloatValue("itemPosX", 0, -1, 1);
    public static FloatValue itemPosY = new FloatValue("itemPosY", 0, -1, 1);
    public static FloatValue itemPosZ = new FloatValue("itemPosZ", 0, -1, 1);
    public static FloatValue Scale = new FloatValue("Scale", 1, 0, 2);
    public String getTag() {
        return getModeValue.get();
    }
}