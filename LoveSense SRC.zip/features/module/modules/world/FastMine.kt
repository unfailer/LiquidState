/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.player


import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.block.Block
import net.minecraft.init.Blocks
import net.minecraft.network.play.client.C07PacketPlayerDigging
import net.minecraft.util.BlockPos
import net.minecraft.util.EnumFacing

@ModuleInfo(name = "FastMine", description = "Allows you to break blocks faster.", category = ModuleCategory.PLAYER)
class FastMine : Module() {
    private var bzs = false
    private var bzx = 0.0f
    var blockPos: BlockPos? = null
    var facing: EnumFacing? = null
    private val nSpeedc = FloatValue("SpeedMine_MinSpeed",0.5f, 0.0f, 1.0f)
    private val xSpeedc = FloatValue("SpeedMine_MaxSpeed", 0.5f, 0.0f, 1.0f)
    private val Speed = FloatValue("SpeedMine_Block", 0.7f, 0.0f, 3.0f)
    private val auto = BoolValue("SpeedMine_AutoSpeed", true)
    var nSpeed: Double? = null
    var xSpeed: Double? = null
    var Damage = 0f
    var isDamagej = 0f

    @EventTarget
    fun onPacket(event:  PacketEvent) {
        val packet = event.packet
        if (packet is C07PacketPlayerDigging && !mc.playerController.extendedReach() && mc.playerController != null) {
            if (packet.getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                bzs = true
                this.blockPos = packet.getPosition()
                this.facing = packet.getFacing()
                bzx = 0.0f
            } else if (packet.getStatus() == C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK || packet.getStatus() == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                bzs = false
                blockPos = null
                facing = null
            }
        }
        if (packet is C07PacketPlayerDigging) {
            if (packet.getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                blockPos = packet.getPosition()
                facing = packet.getFacing()
            }
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (auto.get()) {
            if (mc.playerController.curBlockDamageMP != Damage) {
                isDamagej = mc.playerController.curBlockDamageMP - Damage
                Damage = mc.playerController.curBlockDamageMP
            }
            if (Damage + isDamagej != mc.playerController.curBlockDamageMP) {
                nSpeed = 0.7
                xSpeed = 0.4
            } else {
                nSpeed = isDamagej * 0.5 - 0.1
                xSpeed = isDamagej * 0.7
            }
        } else {
            nSpeed = nSpeedc.get().toDouble()
            xSpeed = xSpeedc.get().toDouble()
        }
        if (mc.playerController.extendedReach()) {
            mc.playerController.blockHitDelay = 0
            mc.playerController.curBlockDamageMP = 0.7f
        } else if (mc.playerController.curBlockDamageMP.toDouble() > nSpeed!!.toDouble()) {
            val block: Block = mc.theWorld.getBlockState(blockPos).block
            bzx += (block.getPlayerRelativeBlockHardness(mc.thePlayer, mc.theWorld, blockPos).toDouble() * Speed.get().toDouble()).toFloat()
            if (bzx > 0.0f && mc.playerController.curBlockDamageMP.toDouble() >= xSpeed!!.toDouble()) {
                mc.theWorld.setBlockState(blockPos, Blocks.air.defaultState, 11)
                mc.thePlayer.sendQueue.networkManager.sendPacket(C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, blockPos, facing))
                bzx = 0.0f
                mc.playerController.curBlockDamageMP = 0.7f
            }
        }
    }
}
