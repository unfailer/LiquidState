/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import io.netty.util.internal.ThreadLocalRandom
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.Fly
import net.ccbluex.liquidbounce.utils.MathUtil
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.entity.EntityLivingBase
import net.minecraft.network.Packet
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import kotlin.jvm.internal.Intrinsics




@ModuleInfo(name = "Criticals", description = "Automatically deals critical hits.", category = ModuleCategory.COMBAT)
class Criticals : Module() {

    val modeValue = ListValue("Mode", arrayOf("Packet", "NcpPacket","Watchdog" ,"Watchdog8", "NoGround" ,"Hop", "TPHop", "Jump", "LowJump"), "Watchdog")
    val delayValue = IntegerValue("Delay", 0, 0, 500)
    private val hurtTimeValue = IntegerValue("HurtTime", 10, 0, 10)
    val msTimer = MSTimer()
    private var inc  = 0
    override fun onEnable() {
        if (modeValue.get().equals("NoGround", ignoreCase = true))
            mc.thePlayer.jump()
    }

    @EventTarget
    fun onAttack(event: AttackEvent) {
        if (event.targetEntity is EntityLivingBase) {
            val entity = event.targetEntity

            if (!mc.thePlayer.onGround || mc.thePlayer.isOnLadder || mc.thePlayer.isInWeb || mc.thePlayer.isInWater ||
                    mc.thePlayer.isInLava || mc.thePlayer.ridingEntity != null || entity.hurtTime > hurtTimeValue.get() ||
                    LiquidBounce.moduleManager[Fly::class.java]!!.state || !msTimer.hasTimePassed(delayValue.get().toLong()))
                return
            val x = mc.thePlayer.posX
            val y = mc.thePlayer.posY
            val z = mc.thePlayer.posZ
            val var6: DoubleArray
            val llllllllllllllllIllIIIllIlllllIl: DoubleArray
            var llllllllllllllllIllIIIllIllllllI: Int
            val llllllllllllllllIllIIIllIllIlIll: Int
            when (modeValue.get().toLowerCase()) {
                "Watchdog" -> {
                    val p = doubleArrayOf(0.045, 0.0010000275, 0.0436, 0.0010000275)
                    var i = 0
                    if (ThreadLocalRandom.current().nextBoolean()) while (i < p.size) {
                        var oY = p[i]
                        if (oY + 2.0E-4 <= 0.0625 && oY != 0.0) {
                            oY += MathUtil.randomNumber(-2.0E-4, 2.0E-4)
                        } else if (oY >= 0.0625) {
                            oY += MathUtil.randomNumber(-2.0E-4, 0.0)
                        } else oY += MathUtil.randomNumber(0.0, 2.0E-4)
                        PacketUtils.sendPacketNoEvent(C04PacketPlayerPosition(x, y + oY, z, false))
                        ++i
                    }
                }
                "Watchdog8" -> {
                    llllllllllllllllIllIIIllIlllllIl = doubleArrayOf(0.1, 0.0513 + ThreadLocalRandom.current().nextFloat().toDouble() / 1000.0, 0.04863327)
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.10897235992938976, z, false))
                    llllllllllllllllIllIIIllIllllllI = 0
                    llllllllllllllllIllIIIllIllIlIll = llllllllllllllllIllIIIllIlllllIl.size
                    while (llllllllllllllllIllIIIllIllllllI < llllllllllllllllIllIIIllIllIlIll) {
                        mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + llllllllllllllllIllIIIllIlllllIl[llllllllllllllllIllIIIllIllllllI], z, false))
                        ++llllllllllllllllIllIIIllIllllllI
                    }
                }

                "packet" -> {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.0625, z, true))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y, z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 1.1E-5, z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y, z, false))
                }

                "ncppacket" -> {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.1, z, false));
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.01, z, false));
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.0, z, false));
                    mc.netHandler.addToSendQueue( C04PacketPlayerPosition(x, y + 0.01, z, false));
                }

                "hop" -> {
                    mc.thePlayer.motionY = 0.1
                    mc.thePlayer.fallDistance = 0.1f
                    mc.thePlayer.onGround = false
                }
                "tphop" -> {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.02, z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y + 0.01, z, false))
                    mc.thePlayer.setPosition(x, y + 0.01, z)
                }
                "jump" -> mc.thePlayer.motionY = 0.42
                "lowjump" -> mc.thePlayer.motionY = 0.35
            }
            mc.thePlayer.onCriticalHit(entity)
            msTimer.reset()
        }
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is C03PacketPlayer){
            when (modeValue.get().toLowerCase()) {
                "noground" -> packet.onGround = false


            }
        }
    }


    override val tag: String?
        get() = modeValue.get()
}
