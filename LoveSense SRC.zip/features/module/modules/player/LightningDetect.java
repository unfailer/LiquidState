package net.ccbluex.liquidbounce.features.module.modules.player;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.PacketEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;

@ModuleInfo(name = "LightningDetect", description = "LightningDetect", category = ModuleCategory.PLAYER)
public class LightningDetect extends Module {
    @EventTarget
    public void onPacket(PacketEvent packetEvent) {
        if(packetEvent.getPacket() instanceof S2CPacketSpawnGlobalEntity) {
            S2CPacketSpawnGlobalEntity packetIn = (S2CPacketSpawnGlobalEntity)packetEvent.getPacket();
            if(packetIn.func_149053_g() == 1) {
                int x = (int)((double)packetIn.func_149051_d() / 32.0D);
                int y = (int)((double)packetIn.func_149050_e() / 32.0D);
                int z = (int)((double)packetIn.func_149049_f() / 32.0D);
                ClientUtils.displayChatMessage("§cDetected Lightning XYZ: " + x +"," + y +"," + z);
            }
        }
    }
}
