package net.ccbluex.liquidbounce.features.module.modules.movement;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.movement.Fly;
import net.ccbluex.liquidbounce.utils.timer.MSTimer;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition;
import net.minecraft.util.AxisAlignedBB;

@ModuleInfo(
        name = "AntiFall",
        description = "Void",
        category = ModuleCategory.MOVEMENT
)
public class AntiFall extends Module {
    private final BoolValue voidcheck = new BoolValue("Void", true);
    private final FloatValue distance = new FloatValue("FallDistance", 1.0F, 1.0F, 20.0F);
    MSTimer timer = new MSTimer();
    private boolean saveMe;

    @EventTarget
    public void onMove(MoveEvent event) {
        if(this.saveMe && this.timer.delay(150.0F) || mc.thePlayer.isCollidedVertically) {
            this.saveMe = false;
            this.timer.reset();
        }

        float dist = ((Float)this.distance.get()).floatValue();
        if(mc.thePlayer.fallDistance > dist && !LiquidBounce.moduleManager.getModule(Fly.class).getState() && (!((Boolean)this.voidcheck.get()).booleanValue() || !this.isBlockUnder())) {
            if(!this.saveMe) {
                this.saveMe = true;
                this.timer.reset();
            }

            mc.thePlayer.fallDistance = 0.0F;
            mc.thePlayer.sendQueue.addToSendQueue(new C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 12.0D, mc.thePlayer.posZ, false));
        }

    }

    private boolean isBlockUnder() {
        if(mc.thePlayer.posY < 0.0D) {
            return false;
        } else {
            for(int off = 0; off < (int)mc.thePlayer.posY + 2; off += 2) {
                AxisAlignedBB bb = mc.thePlayer.getEntityBoundingBox().offset(0.0D, (double)(-off), 0.0D);
                if(!mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, bb).isEmpty()) {
                    return true;
                }
            }

            return false;
        }
    }

    public String getTag() {
        return String.valueOf(((Float)this.distance.get()).floatValue());
    }
}
